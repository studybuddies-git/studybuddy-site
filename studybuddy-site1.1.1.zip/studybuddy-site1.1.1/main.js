//This is the main express/nodejs file that will run much of the site
//
//If you are inspecting element in the browser for this site, fuck off this ain't yo property homie
//

//configuration---------------------------------
//require segment for configuration
var express = require('express');
var app = express();
var formidable = require('formidable');
var assert = require('assert'); //Might not be needed

    //vulnerability patch for security
    app.disable('x-powered-by');
    //express handlebars require
    var handlebars = require('express-handlebars').create({defaultLayout: 'main'});
    app.engine('handlebars', handlebars.engine);
    app.set('view engine', 'handlebars');
    //body-parser require
    app.use(require('body-parser').urlencoded({
        extended: true
    }));
    //cookies for security
    var credentials = require('./credentials.js');
    app.use(require('cookie-parser')(credentials.cookieSecret));

    //port setup and directory referencing for public files
    app.set('port', process.enf.PORT || 80);
    //app.use(express.static(__dirname + '/public'));
    //app.use(express.static(__dirname + '/public/style.css'));
//----------------------------------------------

//url rendering---------------------------------
//render homepage
app.get('/', function(req, res){
    res.sendfile('index.html');
});
//render login
app.get('/login', function(req, res){
    res.sendfile('login.html');
});
//render tutor page
app.get('/tutors', function(req, res){
    res.sendfile('table.html');
});
//render whyTo page
app.get('/why', function(req, res){
    res.sendfile('whyTo.html');
});
//render registry
app.get('/register', function(req, res){
    res.sendfile('register.html');
});
//render settings
app.get('/settings', function(req, res){
    res.sendfile('settings.html', {csrf: 'CSRF token here'});
});
//render thankyou
app.get('/thankyou', function(req, res){
    res.sendfile('thankyou.html');
})
//----------------------------------------------

//feedback email send---------------------------
app.post('/process?form=contactus', function(req, res){
    const mailer = require('nodemailer');
    const smtp = require('nodemailer-smtp-transport');
    async function mailjet(){
            const transport = mailer.createTransport(
                    smtp({
                            host: 'in.mailjet.com',
                            port: 2525,
                            auth: {
                                    user:   process.env.MAILJET_API_KEY || '9ab14aa0e9e4f8ef92aa656ded62b866',
                                    pass: process.env.MAILJET_API_SECRET || '8662e20fad35d630ef817a12bb7f29a6',
                            },
                    })
            );
            const json = await transport.sendMail({
                    from: 'fhs.studybuddies@gmail.com',
                    to: 'fhs.studybuddies@gmail.com',
                    subject: req.body.email,
                    text: req.body.ques,
            });
        console.log(json);
        console.log(req.query.form);
        console.log(req.body._csrf);
    }
    res.redirect(303, 'https://www.study-buddies.net/thankyou.html');
    mailjet();
});
//----------------------------------------------

//file upload-----------------------------------
app.get('/profile-edit', function(req, res){
    var now = new Date();
    res.render('profile-edit', {
        year: now.getFullYear(),
        month: now.getMonth()
    });
});
app.post('/profile-edit/:year/:month', function(req, res){
    var form = new formidable.IncomingForm();
    form.parse(req, functon(err, fields, file)){
        if(err)
            return res.redirect(303, 'errors/errors.html');
        console.log('Received an Image');
        console.log(file);
        res.redirect(303, 'thankyou.html');
    });
});
//----------------------------------------------

//user account creation-------------------------
// This is made to use with mongodb
app.get('/get-account-info', function(req, res, next){
    var resultArray = [];
    mongo.connect(url, function(err, db) {
        assert.equal(null, err);
        var cursor = db.collection('user-data').find();
        cursor.forEach(function(doc, err) {
            assert.equal(null, err);
            resultArray.push(doc);
        }, function() {
            db.close();
            //render new site
        });
    });
});

app.post('/register-account', function(req, res, next) {
    var account = {
        firstname: req.body.fname,
        lastname: req.body.lname,
        idnumber: req.body.idnumber,
        password: req.body.password, //Add encryption here
        subject: req.body.subject,
        email: req.body.email
    };

    mongo.connect(url, function(err, db){
        assert.equal(null, err);
        db.collection('user-data').insertOne(item, function(err, result) {
            assert.equal(null, err);
            console.log('Item inserted');
            db.close();
        });
    });
});
//----------------------------------------------

//error pages for session failure---------------
app.use(function(req, res){
    res.type('text/html');
    res.status(404);
    res.sendfile('errors/404.html');
});
app.use(function(err, req, res, next){
    console.error(err.stack);
    res.status(500);
    res.sendfile('errors/500.html');
});
//----------------------------------------------

//listen to port--------------------------------
app.listen(app.get('port'), function(){
    console.log('Express started on https://www.study-buddies.net : port ' + app.get('port') + 'press Ctrl-C to terminate');
});
//----------------------------------------------