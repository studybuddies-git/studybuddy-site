//Route for User Registration and Authentication to Ensure No Dupes

const {User, validate} = require('../models/userSchema');
const express = require('express');
const router = express.Router();

router.post('/register', async(req, res) => {
    //Validate the Request
    const { error } = validate {req.body};
    if(error){
        return res.status(400).send(error.details[0].message);
    }
    //Checking User Existence
    let user = await User.findOne({email: req.body.email});
    if(user){
        return res.status(400).send('This User Already Exists...');
    } else {
        //Insert New User After Checking
        user = new User({
            name: req.body.name,
            email: req.body.email,
            id: req.body.idnumber,
            subject: req.body.subject,
            password: req.body.password
        });
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
        await user.save();
        res.send(user);
    }
});

module.exports = router;
