window.onload = function() {
    var elm = document.querySelector('.navbar-toggle')
    if(!elm.classList.contains('collapsed')){
        elm.classList.add('collapsed')
    }


    var images = document.querySelectorAll('.hero_image')
 
    for (var i = 0; i < images.length; i++) {
    var image = images[i];
    
    /*image.animate(image.keyframes, 2000);*/
    $(image).delay(i * 100).animate({left: '0%'}, 1000);
    }
    document.body.style.overflowX = "hidden";
}