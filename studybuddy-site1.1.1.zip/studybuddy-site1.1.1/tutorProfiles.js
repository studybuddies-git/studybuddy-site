function dave() {
    document.getElementById('name').innerHTML = 'Dave'
    document.getElementById('info').innerHTML = 'Good a Chem and CS'
}

function lisa() {
    document.getElementById('name').innerHTML = 'Lisa'
    document.getElementById('info').innerHTML = 'Good a Cal and CS'
}