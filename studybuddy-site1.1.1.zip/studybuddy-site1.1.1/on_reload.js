window.onload = function() {
    var elm = document.querySelector('.navbar-toggle')
    if(!elm.classList.contains('collapsed')){
        elm.classList.add('collapsed')
    }
}