Ankur Ahir: Assignment 2
sharon:
sally:

Assignment 1: table.html looks like shit someone make that look sexy with DOM in order to pull up tutors

Assignment 2: user profile page with picture, bio, contact(instagram, email), button(select as tutor), subject, and what grade they are in, general schedule

Assignment 3: tutorHome.html home page for the tutor once they login with way to edit bio, pics, etc. and also have a button to redirect to email notification webpage.

put the number you want by your name (i.e. Mj: assignment 2)

COMMMENT EVERYTHING YOU DO