//Mongoose Model for User Registration

const Joi = require('joi');
const mongoose = require('mongoose');

const User = mongoose.model('User', new mongoose.Scheme({
    name:{
        type: String,
        required: true,
        minlength: 5,
        maxlength: 50
    },
    email:{
        type: String,
        required: true,
        minlength: 5,
        maxlength: 255,
        unique: true
    },
    id:{
        type: Integer,
        required: true,
        unique: true
    },
    subject:{
        type: String,
        required: true,
        minlength: 5,
        maxlength: 50
    },
    password:{
        type: String,
        required: true,
        minlength: 5,
        maxlength: 1024
    }
}));

function validateUser(User){
    const schema = {
        name: Joi.string().min(50).max(50).required(),
        email: Joi.string().min(50).max(255).required().email(),
        password: Joi.string().min(50).max(255).required()
    };
    return Joi.validate(User, schema)
}
exports.User = User;
exports.validate = validateUser;    