//File Name: emailSend.js
//
//This file will send the user input as an email to our email
//
//author: Mj Burog
//

//necessary variables for storage
var feedback;
var email;
var information;
var nodemailer = require('nodemailer');

//stores message into variable for concatenation
function getMessage(){
      feedback = document.getElementById("messageForm").value;
}
//stores email into variable for concatenation
function getEmail(){
      email = document.getElementById("emailForm").value;
}
/*function sendEmail(){
      information = feedback + "\nemail: " + email

      Email.send({
        Host: "smtp.gmail.com",
        Username: "fhs.studybuddies@gmail.com",
        Password: "SB!+f@69",
        To: "fhs.studybuddies@gmail.com",
        From: email,
        Subject: "Feedback message from: " + email,
        Body: information,
      })
      .then(function (message){
          alert("Thank you for your feedback! The Study Buddies team will respond as soon as possible!")
      });
}*/
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'fhs.studybuddies@gmail.com',
      pass: 'SB!+f@69'
    }
});
var mailOptions = {
    from: 'fhs.studybuddies@gmail.com',
    to: 'fhs.studybuddies@gmail.com',
    subject: 'Message from ' + email,
    text: feedback
};
transporter.sendMail(mailOptions, function(error, info){
    if(error){
      console.log(error);
    } else{
      console.log('Email sent: ' + info.response);
    }
})
